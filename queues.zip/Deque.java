import java.util.Iterator;
import java.util.NoSuchElementException;



public class Deque<Item> implements Iterable<Item> {
    
   private int n;                           // size of deque
   private Node first;                      // top of deque
   private Node last;                       // bottom of deque
   
   // helper linked list class
   private class Node {   
       private Item item;
       private Node next;
       private Node previous;
   }
   
   /**
    * Initialize an empty deque.
    */
        
   public Deque() {
       n = 0;
       first = null;
       last = null;   
   }
   
   /**
    * Is this deque is empty?
    * @return true if deque is empty; false otherwise
    */
   
   public boolean isEmpty() {
       return first == null && last == null;   
   }
   
   /**
    * Returns the number of items on the deque
    * @return the number of items on the deque
    */
   
   public int size() {
       return n;   
   }
   
   /**
    * Adds the item to the front of the deque
    * @param item the item to add
    */
     
   public void addFirst(Item item) {
       if (item == null) { throw new NullPointerException("Danger"); }
       Node oldfirst = first;
       first = new Node();
       first.item = item;
       first.next = oldfirst;
       first.previous = null;
       n++;
       if (this.size() == 1) { 
           last = first;
       } 
       else { 
           oldfirst.previous = first; 
           if (this.size() == 2) {
           last = oldfirst;
           last.next = null;
           }
       }
   }
   
   /**
    * Adds the item to the end
    * @param item the item to add
    */
   
   public void addLast(Item item) {  
       if (item == null) { throw new NullPointerException(); }
       Node oldlast = last;
       last = new Node();
       last.item = item;
       last.previous = oldlast;
       last.next = null;
       n++;
       if (this.size() == 1) {
           first = last;
       } 
       else { 
           oldlast.next = last;
           if (this.size() == 2) {
           first = oldlast;
           first.previous = null;
           }
       }
   }
   
   /**
    * Removes the item from the top
    * @return the item from the top
    */
      
   public Item removeFirst() {
       if (this.isEmpty()) throw new NoSuchElementException();
       Item item = first.item;
       if (this.size() != 1) { first = first.next; }
       first.previous = null;
       n--;
       return item;
       
   }    
   public Item removeLast() {
       if (this.isEmpty()) throw new NoSuchElementException();
       Item item = last.item;
       if (this.size() != 1) { last = last.previous; }
       last.next = null;
       n--;
       return item;
   } 
   
   public Iterator<Item> iterator() {
        return new DequeIterator();
    }
   
   private class DequeIterator implements Iterator<Item> { 
        private Node current = first;
        public boolean hasNext()  { return current != null;                     }
        public void remove()      { throw new UnsupportedOperationException();  }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            Item item = current.item;
            current = current.next; 
            return item;
        }
    }
  /* public String toString() {
               StringBuilder s = new StringBuilder();
        for (Item item : this)
            s.append(item + " ");
        return s.toString();   
   } */
   
   public static void main(String[] args)   {
       Deque<String> deque = new Deque<String>();
 
       System.out.println(deque.isEmpty());
       deque.addFirst("0");
       System.out.println(deque.removeFirst()); 
       System.out.println(deque.toString());
       System.out.println(deque.size());  
       System.out.println(deque.isEmpty()); 
       deque.addFirst("-1");
       System.out.println(deque.toString());
       System.out.println(deque.size());  
       System.out.println(deque.isEmpty()); 
       deque.addFirst("-2");
       System.out.println(deque.toString());
       System.out.println(deque.size());  
       System.out.println(deque.isEmpty());
       System.out.println(deque.toString());
       System.out.println(deque.size());  
       System.out.println(deque.removeFirst()); 
       deque.addFirst("1");
       System.out.println(deque.toString());
       System.out.println(deque.size());  
       System.out.println(deque.isEmpty()); 
       deque.addFirst("2");
       System.out.println(deque.toString());
       System.out.println(deque.size());  
       System.out.println(deque.isEmpty()); 
       deque.addFirst("3");
       System.out.println(deque.toString());
       System.out.println(deque.size());  
       System.out.println(deque.isEmpty());
       System.out.println(deque.removeFirst()); 
       System.out.println(deque.removeFirst()); 
       System.out.println(deque.removeFirst()); 
       deque.addFirst("31");
       System.out.println(deque.toString());
       deque.addFirst("32");
       System.out.println(deque.toString());
      
   
   
   }
}
